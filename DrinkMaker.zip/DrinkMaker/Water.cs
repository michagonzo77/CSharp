class Water : Drink
{
    public Water() : base("H20", "Clear", 60.00, false, 0)
    {
        
    }
}